package com.example.administrator.shiyuji.ui.fragment.adapter;

/**
 * Created by Administrator on 2019/7/4.
 */

public interface FragmentPagerChangeListener {
    void instantiate(String var1);

    void destroy(String var1);
}
