package com.example.administrator.shiyuji.support.sqlit.extra;

/**
 * Created by Administrator on 2019/7/8.
 */
public class AutoIncrementTableColumn extends TableColumn {
    public AutoIncrementTableColumn() {
    }
}