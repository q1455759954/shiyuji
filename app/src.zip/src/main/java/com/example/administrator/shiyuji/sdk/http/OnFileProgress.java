package com.example.administrator.shiyuji.sdk.http;

/**
 * Created by Administrator on 2019/12/15.
 */

public interface OnFileProgress {
    void onProgress(long var1, long var3);
}

