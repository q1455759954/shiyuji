package com.example.administrator.shiyuji.support.permissions;

/**
 * Created by Administrator on 2019/8/3.
 */

public interface IPermissionsObserver {
    void onRequestPermissionsResult(int var1, String[] var2, int[] var3);
}