package com.example.administrator.shiyuji.sdk.http;

/**
 * Created by Administrator on 2019/7/8.
 */

public class HttpsUtility {
}
