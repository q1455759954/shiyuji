package com.example.administrator.shiyuji.ui.widget.support.bitmap;

/**
 * Created by Administrator on 2019/7/2.
 */
public interface BitmapOwner {
    boolean canDisplay();
}
