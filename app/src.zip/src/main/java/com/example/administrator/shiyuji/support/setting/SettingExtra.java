package com.example.administrator.shiyuji.support.setting;

import java.io.Serializable;

/**
 * Created by Administrator on 2019/7/2.
 */
public class SettingExtra extends SettingBean implements Serializable {
    private static final long serialVersionUID = 4608815242740722900L;

    public SettingExtra() {
    }
}